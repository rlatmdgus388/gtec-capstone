import { NextResponse } from 'next/server';
import { firestore } from '@/lib/firebase-admin';
import admin from 'firebase-admin';

// 특정 단어를 수정합니다.
export async function PUT(request: Request, { params }: { params: { wordbookId: string, wordId: string } }) {
  try {
    const { wordbookId, wordId } = params;
    const { word, meaning, example, pronunciation, mastered } = await request.json();

    const updateData: { [key: string]: any } = {};
    if (word !== undefined) updateData.word = word;
    if (meaning !== undefined) updateData.meaning = meaning;
    if (example !== undefined) updateData.example = example;
    if (pronunciation !== undefined) updateData.pronunciation = pronunciation;
    if (mastered !== undefined) updateData.mastered = mastered;

    if (Object.keys(updateData).length === 0) {
      return NextResponse.json({ message: '수정할 데이터가 없습니다.' }, { status: 400 });
    }

    await firestore
      .collection('wordbooks')
      .doc(wordbookId)
      .collection('words')
      .doc(wordId)
      .update(updateData);

    return NextResponse.json({ message: '단어가 성공적으로 수정되었습니다.' });
  } catch (error) {
    console.error("단어 수정 오류:", error);
    return NextResponse.json({ message: '서버 오류가 발생했습니다.' }, { status: 500 });
  }
}

// 특정 단어를 삭제합니다.
export async function DELETE(request: Request, { params }: { params: { wordbookId: string, wordId: string } }) {
    try {
        const { wordbookId, wordId } = params;

        await firestore
            .collection('wordbooks')
            .doc(wordbookId)
            .collection('words')
            .doc(wordId)
            .delete();
        
        // 단어장 문서의 wordCount 필드 1 감소
        await firestore.collection('wordbooks').doc(wordbookId).update({
          wordCount: admin.firestore.FieldValue.increment(-1)
        });

        return new Response(null, { status: 204 }); // No Content
    } catch (error) {
        console.error("단어 삭제 오류:", error);
        return NextResponse.json({ message: '서버 오류가 발생했습니다.' }, { status: 500 });
    }
}
