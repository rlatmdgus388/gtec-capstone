import AuthManager from "@/components/auth/AuthManager";

export default function Home() {
  return (
    <main>
      <AuthManager />
    </main>
  );
}
